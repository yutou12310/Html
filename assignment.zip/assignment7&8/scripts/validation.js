// Defining a function to display error message
function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

// Defining a function to validate form
function validateForm() {
    // review the element in the blank
    var name = document.contactForm.name.value;

    var email = document.contactForm.email.value;

    var mobile = document.contactForm.mobile.value;

    var country = document.contactForm.country.value;

    var gender = document.contactForm.gender.value;

    // define error variables 
    var nameErr = emailErr = mobileErr = countryErr = genderErr = true;

    // test Valid name
    if (name == "") {
        printError("nameErr", "Hi, you forgot your name");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(name) === false) {
            printError("nameErr", "Sorry, your name is invalid");
        } else {
            printError("nameErr", "");
            nameErr = false;
        }
    }

    // Validate email address
    if (email == "") {
        printError("emailErr", "It seems you have forgot your e-mail");
    } else {
        // Regular expression for basic email validation
        var regex = /^\S+@\S+\.\S+$/;
        if (regex.test(email) === false) {
            printError("emailErr", "Sorry, your e-mail address is invalid");
        } else {
            printError("emailErr", "");
            emailErr = false;
        }
    }

    // Validate mobile number
    if (mobile == "") {
        printError("mobileErr", "Can you give me your phone number？");
    } else {
        var regex = /^[1-10]\d{10}$/;
        if (regex.test(mobile) === false) {
            printError("mobileErr", "Sorry, your number is not correct");
        } else {
            printError("mobileErr", "");
            mobileErr = false;
        }
    }

    // Validate country
    if (country == "") {
        printError("countryErr", "Please select your country");
    } else {
        printError("countryErr", "");
        countryErr = false;
    }

    // Validate gender
    if (gender == "") {
        printError("genderErr", "Are you a boy or a girl? ");
    } else {
        printError("genderErr", "");
        genderErr = false;
    }

    // Prevent the form from being submitted if there are any errors
    if ((nameErr || emailErr || mobileErr || countryErr || genderErr) == true) {
        return false;
    } else {

        // Creating a string from input data for preview
        var dataPreview = "You've entered the following details: \n" +
            "Full Name: " + name + "\n" +
            "Email Address: " + email + "\n" +
            "Mobile Number: " + mobile + "\n" +
            "Country: " + country + "\n" +
            "Gender: " + gender + "\n";

        // Display input data in a dialog box before submitting the form
        alert(dataPreview);
    }
};